/*
  Warnings:

  - You are about to drop the column `pelanggan_dilayani` on the `praktek` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `praktek` DROP COLUMN `pelanggan_dilayani`;
