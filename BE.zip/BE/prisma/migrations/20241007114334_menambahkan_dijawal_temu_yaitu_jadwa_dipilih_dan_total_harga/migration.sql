-- AlterTable
ALTER TABLE `jadwal_temu` ADD COLUMN `total_harga` VARCHAR(255) NULL,
    ADD COLUMN `waktu_dipilih_pelanggan` VARCHAR(255) NULL;
