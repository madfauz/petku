-- AlterTable
ALTER TABLE `jadwal_temu` ADD COLUMN `status` VARCHAR(255) NULL;
