-- AlterTable
ALTER TABLE `rekam_medis` ADD COLUMN `catatan_pasien` VARCHAR(225) NULL;
