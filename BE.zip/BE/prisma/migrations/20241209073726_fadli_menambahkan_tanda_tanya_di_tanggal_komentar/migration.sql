-- AlterTable
ALTER TABLE `rekam_medis` MODIFY `tanggal_komentar` VARCHAR(225) NULL;
